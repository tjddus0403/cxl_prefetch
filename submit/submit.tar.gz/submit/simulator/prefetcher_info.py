
NONE = "none"
NLINE = "nline"
BO = "bo"
LEAP = "leap"
RA = "ra"
CLSTM = "clstm"